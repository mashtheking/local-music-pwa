document.documentElement.setAttribute('app-not-supported', '')
